<?php

use App\Http\Controllers\CentralAuth\RegisterController;
use App\Http\Controllers\LandingController;
use App\Http\Controllers\Storefront\CartController;
use App\Http\Controllers\Storefront\CheckoutController;
use App\Http\Controllers\Storefront\HomeController as StorefrontHome;
use App\Http\Controllers\Storefront\ProductController as StorefrontProduct;
use App\Http\Controllers\Tenant\BarcodeController;
use App\Http\Controllers\Tenant\BillingController;
use App\Http\Controllers\Tenant\CategoryController;
use App\Http\Controllers\Tenant\CourierController;
use App\Http\Controllers\Tenant\CustomerController;
use App\Http\Controllers\Tenant\FraudCheckController;
use App\Http\Controllers\Tenant\PosController;
use App\Http\Controllers\Tenant\SettingController;
use App\Http\Controllers\Tenant\DashboardController;
use App\Http\Controllers\Tenant\InventoryController;
use App\Http\Controllers\Tenant\OrderController;
use App\Http\Controllers\Tenant\ProductController;
use App\Http\Controllers\TenantAuth\LoginController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| 1. CENTRAL  (metasoftbd.com)
|--------------------------------------------------------------------------
*/
Route::domain(config('app.central_domain'))->group(function () {

    Route::get('/', [LandingController::class, 'index'])->name('landing');

    Route::get('/register', [RegisterController::class, 'show'])->name('register');
    Route::post('/register', [RegisterController::class, 'store'])->name('register.store');

    Route::get('/login', fn () => view('central.find-shop'))->name('central.login');
    Route::post('/login', function () {
        $sub = strtolower(trim(request('subdomain', '')));
        $tenant = \App\Models\Tenant::where('subdomain', $sub)->first();

        return $tenant
            ? redirect()->away($tenant->url() . '/panel/login')
            : back()->withErrors(['subdomain' => 'এই নামে কোনো দোকান পাওয়া যায়নি।']);
    })->name('central.login.find');

    /* ---------------- SUPER ADMIN ---------------- */
    Route::prefix('super-admin')->name('super.')->group(function () {
        Route::get('login', [\App\Http\Controllers\SuperAdmin\AuthController::class, 'show'])->name('login');
        Route::post('login', [\App\Http\Controllers\SuperAdmin\AuthController::class, 'login'])->name('login.attempt');
        Route::post('logout', [\App\Http\Controllers\SuperAdmin\AuthController::class, 'logout'])->name('logout');

        Route::middleware('auth:super_admin')->group(function () {
            Route::get('/', [\App\Http\Controllers\SuperAdmin\DashboardController::class, 'index'])->name('dashboard');

            Route::get('tenants', [\App\Http\Controllers\SuperAdmin\TenantController::class, 'index'])->name('tenants');
            Route::get('tenants/{tenant}', [\App\Http\Controllers\SuperAdmin\TenantController::class, 'show'])->name('tenants.show');
            Route::post('tenants/{tenant}/suspend', [\App\Http\Controllers\SuperAdmin\TenantController::class, 'suspend'])->name('tenants.suspend');
            Route::post('tenants/{tenant}/activate', [\App\Http\Controllers\SuperAdmin\TenantController::class, 'activate'])->name('tenants.activate');
            Route::post('tenants/{tenant}/extend', [\App\Http\Controllers\SuperAdmin\TenantController::class, 'extend'])->name('tenants.extend');

            Route::get('payments', [\App\Http\Controllers\SuperAdmin\PaymentController::class, 'index'])->name('payments');

            Route::get('plans', [\App\Http\Controllers\SuperAdmin\PlanController::class, 'index'])->name('plans');
            Route::put('plans/{plan}', [\App\Http\Controllers\SuperAdmin\PlanController::class, 'update'])->name('plans.update');
        });
    });
});

/*
|--------------------------------------------------------------------------
| 2. TENANT ROUTES
|--------------------------------------------------------------------------
*/
$tenantRoutes = function () {

    /* ---------- 2a. TENANT ADMIN PANEL (/panel) ---------- */
    Route::prefix('panel')->name('tenant.')->group(function () {

        Route::get('login', [LoginController::class, 'show'])->name('login');
        Route::post('login', [LoginController::class, 'login'])->name('login.attempt');
        Route::post('logout', [LoginController::class, 'logout'])->name('logout');

        // Payment gateway redirects back here (GET + POST, no auth/session guaranteed)
        Route::match(['get', 'post'], 'billing/callback/{gateway}', [BillingController::class, 'callback'])
            ->name('billing.callback')->withoutMiddleware([\Illuminate\Foundation\Http\Middleware\ValidateCsrfToken::class]);

        Route::middleware(['auth:tenant', 'check.subscription'])->group(function () {

            Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

            // Billing
            Route::get('billing', [BillingController::class, 'index'])->name('billing');
            Route::post('billing/pay', [BillingController::class, 'pay'])->name('billing.pay');

            // Catalog
            Route::get('categories', [CategoryController::class, 'index'])->name('categories.index');
            Route::post('categories', [CategoryController::class, 'store'])->name('categories.store');
            Route::delete('categories/{category}', [CategoryController::class, 'destroy'])->name('categories.destroy');

            Route::get('products', [ProductController::class, 'index'])->name('products.index');
            Route::get('products/create', [ProductController::class, 'create'])->name('products.create');
            Route::post('products', [ProductController::class, 'store'])->name('products.store');
            Route::get('products/{product}/edit', [ProductController::class, 'edit'])->name('products.edit');
            Route::put('products/{product}', [ProductController::class, 'update'])->name('products.update');
            Route::delete('products/{product}', [ProductController::class, 'destroy'])->name('products.destroy');
            Route::get('products/{product}/barcodes', [BarcodeController::class, 'print'])->name('products.barcodes');

            // Inventory
            Route::get('inventory', [InventoryController::class, 'index'])->name('inventory');
            Route::post('inventory/adjust', [InventoryController::class, 'adjust'])->name('inventory.adjust');

            // Orders
            Route::get('orders', [OrderController::class, 'index'])->name('orders.index');
            Route::get('orders/{order}', [OrderController::class, 'show'])->name('orders.show');
            Route::post('orders/{order}/status', [OrderController::class, 'updateStatus'])->name('orders.status');
            Route::post('orders/{order}/courier', [CourierController::class, 'send'])->name('orders.courier');
            Route::post('fraud-check', [FraudCheckController::class, 'check'])->name('fraud.check');

            // POS
            Route::get('pos', [PosController::class, 'index'])->name('pos');
            Route::get('pos/scan/{code}', [PosController::class, 'scan'])->name('pos.scan');
            Route::post('pos/sell', [PosController::class, 'sell'])->name('pos.sell');
            Route::get('pos/receipt/{order}', [PosController::class, 'receipt'])->name('pos.receipt');

            // Customers + due khata
            Route::get('customers', [CustomerController::class, 'index'])->name('customers.index');
            Route::get('customers/{customer}', [CustomerController::class, 'show'])->name('customers.show');
            Route::post('customers/{customer}/due', [CustomerController::class, 'receiveDue'])->name('customers.due.receive');

            // Settings
            Route::get('settings', [SettingController::class, 'index'])->name('settings');
            Route::post('settings/courier', [SettingController::class, 'courier'])->name('settings.courier');
            Route::post('settings/store', [SettingController::class, 'store'])->name('settings.store');
        });
    });

    /* ---------- 2b. STOREFRONT (customers, no login) ---------- */
    Route::middleware('check.subscription')->name('storefront.')->group(function () {
        Route::get('/', [StorefrontHome::class, 'index'])->name('home');
        Route::get('/products', [StorefrontProduct::class, 'index'])->name('products');
        Route::get('/product/{slug}', [StorefrontProduct::class, 'show'])->name('product');

        Route::get('/cart', [CartController::class, 'index'])->name('cart');
        Route::post('/cart/add', [CartController::class, 'add'])->name('cart.add');
        Route::post('/cart/update', [CartController::class, 'update'])->name('cart.update');

        Route::get('/checkout', [CheckoutController::class, 'show'])->name('checkout');
        Route::post('/checkout/track', [CheckoutController::class, 'trackIncomplete'])->name('checkout.track');
        Route::post('/checkout', [CheckoutController::class, 'place'])->name('checkout.place');
        Route::get('/order-success/{orderNumber}', [CheckoutController::class, 'success'])->name('order.success');
    });
};

if (config('app.tenancy_mode', 'subdomain') === 'path') {
    Route::domain(config('app.central_domain'))
        ->prefix('shop/{tenant_slug}')
        ->where(['tenant_slug' => '[a-z0-9-]+'])
        ->middleware('resolve.tenant')
        ->group($tenantRoutes);
} else {
    Route::middleware('resolve.tenant')->group($tenantRoutes);
}

/*
|--------------------------------------------------------------------------
| 3. www -> apex redirect
|--------------------------------------------------------------------------
*/
Route::domain('www.' . config('app.central_domain'))->group(function () {
    Route::any('/{any?}', function () {
        return redirect()->away(
            'https://' . config('app.central_domain') . request()->getRequestUri()
        );
    })->where('any', '.*');
});
