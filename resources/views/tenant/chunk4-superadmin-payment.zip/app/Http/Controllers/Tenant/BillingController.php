<?php

namespace App\Http\Controllers\Tenant;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\Models\Subscription;
use App\Models\SubscriptionPayment;
use App\Services\Payment\SslCommerzService;
use Illuminate\Http\Request;

class BillingController extends Controller
{
    public function index()
    {
        $tenant = app('currentTenant');

        return view('tenant.billing', [
            'tenant'   => $tenant,
            'plans'    => Plan::where('is_active', 1)->orderBy('sort_order')->get(),
            'payments' => SubscriptionPayment::withoutGlobalScopes()
                            ->where('tenant_id', $tenant->id)->latest()->limit(10)->get(),
        ]);
    }

    public function pay(Request $request, SslCommerzService $ssl)
    {
        $data = $request->validate([
            'plan_id' => 'required|exists:plans,id',
            'cycle'   => 'required|in:monthly,yearly',
        ]);

        $tenant = app('currentTenant');
        $plan   = Plan::findOrFail($data['plan_id']);
        $amount = $data['cycle'] === 'yearly' ? $plan->price_yearly : $plan->price_monthly;

        $payment = SubscriptionPayment::create([
            'tenant_id' => $tenant->id,
            'gateway'   => 'sslcommerz',
            'amount'    => $amount,
            'status'    => 'pending',
            'gateway_response' => ['plan_id' => $plan->id, 'cycle' => $data['cycle']],
        ]);

        $tranId = 'SUB-' . $tenant->id . '-' . $payment->id;
        $payment->update(['trx_id' => $tranId]);

        $callback = $tenant->url() . '/panel/billing/callback/sslcommerz';

        $session = $ssl->createSession([
            'total_amount' => $amount,
            'tran_id'      => $tranId,
            'success_url'  => $callback,
            'fail_url'     => $callback,
            'cancel_url'   => $callback,
            'cus_name'     => $tenant->owner_name,
            'cus_email'    => $tenant->owner_email,
            'cus_phone'    => $tenant->owner_phone,
            'cus_add1'     => $tenant->store_name,
            'cus_city'     => 'Dhaka',
            'value_a'      => $tenant->id,
        ]);

        if (($session['status'] ?? '') === 'SUCCESS' && ! empty($session['GatewayPageURL'])) {
            return redirect()->away($session['GatewayPageURL']);
        }

        $payment->update(['status' => 'failed', 'gateway_response' => $session]);

        return back()->with('error', 'পেমেন্ট শুরু করা যায়নি: ' . ($session['failedreason'] ?? 'গেটওয়ে সাড়া দেয়নি। অ্যাডমিনের সাথে যোগাযোগ করুন।'));
    }

    /** SSLCommerz redirects the customer's browser back here (POST). */
    public function callback(Request $request, string $gateway, SslCommerzService $ssl)
    {
        $tranId = $request->input('tran_id');
        $status = $request->input('status'); // VALID | FAILED | CANCELLED

        $payment = $tranId
            ? SubscriptionPayment::withoutGlobalScopes()->where('trx_id', $tranId)->first()
            : null;

        if (! $payment) {
            return redirect()->route('tenant.billing')->with('error', 'পেমেন্ট রেকর্ড পাওয়া যায়নি।');
        }

        if ($payment->status === 'completed') {
            return redirect()->route('tenant.billing')->with('success', 'পেমেন্ট আগেই সম্পন্ন হয়েছে।');
        }

        if ($status !== 'VALID') {
            $payment->update(['status' => 'failed', 'gateway_response' => $request->all()]);
            return redirect()->route('tenant.billing')->with('error', 'পেমেন্ট সম্পন্ন হয়নি। আবার চেষ্টা করুন।');
        }

        // server-side validation — never trust the redirect alone
        $validation = $ssl->validate($request->input('val_id', ''));

        if (! in_array($validation['status'] ?? '', ['VALID', 'VALIDATED'])) {
            $payment->update(['status' => 'failed', 'gateway_response' => $validation]);
            return redirect()->route('tenant.billing')->with('error', 'পেমেন্ট ভেরিফাই করা যায়নি। টাকা কাটা গেলে অ্যাডমিনের সাথে যোগাযোগ করুন।');
        }

        $this->activateSubscription($payment, $validation);

        return redirect()->route('tenant.billing')->with('success', '🎉 পেমেন্ট সফল! আপনার সাবস্ক্রিপশন চালু হয়ে গেছে।');
    }

    protected function activateSubscription(SubscriptionPayment $payment, array $validation): void
    {
        $meta   = $payment->gateway_response;
        $planId = $meta['plan_id'] ?? 1;
        $cycle  = $meta['cycle'] ?? 'monthly';
        $days   = $cycle === 'yearly' ? 365 : 30;

        $tenant = \App\Models\Tenant::find($payment->tenant_id);

        $base = ($tenant->subscription_ends_at && $tenant->subscription_ends_at->isFuture())
            ? $tenant->subscription_ends_at
            : now();

        $endsAt = $base->copy()->addDays($days);

        $subscription = Subscription::create([
            'tenant_id'     => $tenant->id,
            'plan_id'       => $planId,
            'billing_cycle' => $cycle,
            'starts_at'     => now(),
            'ends_at'       => $endsAt,
            'status'        => 'active',
        ]);

        $payment->update([
            'status'           => 'completed',
            'subscription_id'  => $subscription->id,
            'paid_at'          => now(),
            'gateway_response' => array_merge($meta, ['validation' => $validation]),
        ]);

        $tenant->update([
            'status'               => 'active',
            'plan_id'              => $planId,
            'subscription_ends_at' => $endsAt,
        ]);
    }
}
