<?php

namespace App\Http\Controllers\SuperAdmin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Plan;
use App\Models\SubscriptionPayment;
use App\Models\Tenant;
use App\Models\User;
use Illuminate\Http\Request;

class TenantController extends Controller
{
    public function index(Request $request)
    {
        $tenants = Tenant::with('plan')
            ->when($request->q, fn ($q) => $q->where(fn ($qq) => $qq
                ->where('store_name', 'like', '%' . $request->q . '%')
                ->orWhere('subdomain', 'like', '%' . $request->q . '%')
                ->orWhere('owner_phone', 'like', '%' . $request->q . '%')
                ->orWhere('owner_email', 'like', '%' . $request->q . '%')))
            ->when($request->status, fn ($q) => $q->where('status', $request->status))
            ->latest()->paginate(25)->withQueryString();

        return view('super.tenants', compact('tenants'));
    }

    public function show(Tenant $tenant)
    {
        return view('super.tenant-show', [
            'tenant'   => $tenant->load('plan'),
            'plans'    => Plan::orderBy('sort_order')->get(),
            'orders'   => Order::withoutGlobalScopes()->where('tenant_id', $tenant->id)->count(),
            'staff'    => User::withoutGlobalScopes()->where('tenant_id', $tenant->id)->count(),
            'payments' => SubscriptionPayment::where('tenant_id', $tenant->id)->latest()->limit(10)->get(),
        ]);
    }

    public function suspend(Tenant $tenant)
    {
        $tenant->update(['status' => 'suspended']);
        return back()->with('success', $tenant->store_name . ' সাসপেন্ড করা হয়েছে।');
    }

    public function activate(Tenant $tenant)
    {
        $status = ($tenant->subscription_ends_at && $tenant->subscription_ends_at->isFuture())
            ? 'active'
            : (($tenant->trial_ends_at && $tenant->trial_ends_at->isFuture()) ? 'trial' : 'expired');

        $tenant->update(['status' => $status]);
        return back()->with('success', $tenant->store_name . ' অ্যাক্টিভেট করা হয়েছে (' . $status . ')।');
    }

    /** Manual extension — e.g. cash/bKash-personal payment taken outside the gateway */
    public function extend(Request $request, Tenant $tenant)
    {
        $data = $request->validate([
            'days'    => 'required|integer|min:1|max:730',
            'plan_id' => 'required|exists:plans,id',
        ]);

        $base = ($tenant->subscription_ends_at && $tenant->subscription_ends_at->isFuture())
            ? $tenant->subscription_ends_at : now();

        $tenant->update([
            'status'               => 'active',
            'plan_id'              => $data['plan_id'],
            'subscription_ends_at' => $base->copy()->addDays($data['days']),
        ]);

        SubscriptionPayment::create([
            'tenant_id' => $tenant->id,
            'gateway'   => 'manual',
            'amount'    => 0,
            'status'    => 'completed',
            'paid_at'   => now(),
            'gateway_response' => ['note' => 'Manual extend ' . $data['days'] . ' days by super admin'],
        ]);

        return back()->with('success', $data['days'] . ' দিন বাড়ানো হয়েছে।');
    }
}
