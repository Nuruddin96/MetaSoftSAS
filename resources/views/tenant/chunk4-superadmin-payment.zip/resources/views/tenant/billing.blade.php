@extends('layouts.panel')

@section('title', 'বিলিং')

@section('content')
<h1 class="font-disp font-bold text-2xl mb-2">সাবস্ক্রিপশন</h1>
<p class="text-sm text-mute mb-6">
    বর্তমান অবস্থা: <b class="text-ink">{{ ['trial' => 'ট্রায়াল', 'active' => 'অ্যাক্টিভ', 'expired' => 'মেয়াদ শেষ', 'suspended' => 'সাসপেন্ডেড'][$tenant->status] ?? $tenant->status }}</b>
    @if ($tenant->status === 'trial' && $tenant->trial_ends_at) — শেষ হবে {{ $tenant->trial_ends_at->format('d M Y') }} @endif
    @if ($tenant->status === 'active' && $tenant->subscription_ends_at) — মেয়াদ {{ $tenant->subscription_ends_at->format('d M Y') }} পর্যন্ত @endif
</p>

@if (session('warning'))
    <p class="mb-4 bg-amber/15 border border-amber/40 rounded-xl p-4 text-sm">{{ session('warning') }}</p>
@endif

<div class="grid md:grid-cols-3 gap-5 max-w-4xl">
    @foreach ($plans as $plan)
        <div class="bg-white rounded-2xl border p-6 flex flex-col {{ $tenant->plan_id === $plan->id ? 'border-leaf ring-2 ring-leaf/20' : 'border-ink/10' }}">
            <div class="flex items-center justify-between">
                <h3 class="font-bold">{{ $plan->name }}</h3>
                @if ($tenant->plan_id === $plan->id)<span class="text-xs bg-leaf/10 text-leafdk px-2 py-0.5 rounded-full font-semibold">বর্তমান</span>@endif
            </div>
            <p class="mt-2"><span class="font-disp font-extrabold text-2xl">{{ number_format($plan->price_monthly) }}৳</span><span class="text-mute text-sm">/মাস</span></p>
            <ul class="mt-4 space-y-2 text-sm text-mute flex-1">
                <li>✓ {{ $plan->max_products ? number_format($plan->max_products) . 'টি প্রোডাক্ট' : 'আনলিমিটেড প্রোডাক্ট' }}</li>
                <li>✓ {{ $plan->max_staff ? $plan->max_staff . ' জন স্টাফ' : 'আনলিমিটেড স্টাফ' }}</li>
                <li>✓ POS, কুরিয়ার, ফ্রড চেকার</li>
            </ul>
            <div class="mt-5 space-y-2">
                <form method="POST" action="{{ route('tenant.billing.pay') }}">
                    @csrf
                    <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                    <input type="hidden" name="cycle" value="monthly">
                    <button class="w-full py-2.5 rounded-lg bg-leaf text-white font-semibold text-sm hover:bg-leafdk">১ মাস — {{ number_format($plan->price_monthly) }}৳</button>
                </form>
                <form method="POST" action="{{ route('tenant.billing.pay') }}">
                    @csrf
                    <input type="hidden" name="plan_id" value="{{ $plan->id }}">
                    <input type="hidden" name="cycle" value="yearly">
                    <button class="w-full py-2.5 rounded-lg border border-ink/15 font-semibold text-sm hover:bg-paper">১ বছর — {{ number_format($plan->price_yearly) }}৳</button>
                </form>
            </div>
        </div>
    @endforeach
</div>
<p class="text-xs text-mute mt-4">💳 পেমেন্ট হয় SSLCommerz-এর নিরাপদ গেটওয়েতে — bKash, Nagad, Rocket, কার্ড সবই চলে।</p>

@if ($payments->isNotEmpty())
    <div class="bg-white rounded-xl border border-ink/5 mt-8 max-w-4xl">
        <div class="px-5 py-3 border-b border-ink/5 font-bold text-sm">পেমেন্ট হিস্ট্রি</div>
        @foreach ($payments as $p)
            <div class="flex justify-between px-5 py-3 border-b border-ink/5 last:border-0 text-sm">
                <span class="text-mute">{{ $p->created_at->format('d M Y') }} · {{ $p->trx_id }}</span>
                <span><span class="font-semibold">{{ number_format($p->amount) }}৳</span>
                    <span class="ml-2 px-2 py-0.5 rounded text-xs {{ ['completed' => 'bg-leaf/10 text-leafdk', 'failed' => 'bg-red-50 text-red-600'][$p->status] ?? 'bg-amber/15' }}">{{ $p->status }}</span></span>
            </div>
        @endforeach
    </div>
@endif
@endsection
